title: mysql时间错误
date: '2019-06-24 12:15:18'
updated: '2019-06-24 12:15:18'
tags: [mysql, 零散问题]
permalink: /articles/2019/06/24/1561349717506.html
---
今天11点注册用户的时间变成了昨天22点。
时间相差13个小时。

查询时区设置
show variable like '%time_zone%'
![timezone.png](https://img.hacpai.com/file/2019/06/timezone-ab6944fd.png)

明确指定 MySQL 数据库的时区
```
[mysqld]
default-time-zone='+08:00'
```
重启mysql：restart  mysqld.service

---
或者通过连接字符串设置serverTimezone。
```
jdbc:p6spy:mysql://xxx:3306/joinus_prod?autoReconnect=true&useSSL=false&characterEncoding=utf-8&zeroDateTimeBehavior=convertToNull
&serverTimezone=Asia/Shanghai
```


