title: 1 IP分类 CIDR
date: '2019-10-28 18:03:22'
updated: '2019-10-28 18:03:22'
tags: [网络协议, 内功]
permalink: /articles/2019/10/28/1572257001787.html
---

查看命令

ip addr

ifconfig

ipconfig

![31.jpg](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pbWcuaGFjcGFpLmNvbS9maWxlLzIwMTkvMTAvMzEtODZhNGViNGYuanBn?x-oss-process=image/format,png)


 

这样类型一分，我们可用的ip就更少了。

所以CIDR (Classless InterDomain Routing) 无类别域间路由选择，就来了，不按你这个分类。

10.100.122.2/24 ，表示前24位是网络号，后面都是主机号。
10.100.122.2/20 ，表示前20位是网络号，后面都是主机号。

为了生活理解一下：
JS、JAVA程序调试；
网站、小程序、APP项目；
qq：1582508336 魔道工程师  
<a href="https://shop107094599.taobao.com/index.htm?spm=a1z10.3-c.w5002-22136070998.2.c912d7b0wHS2uo">淘宝店 秩美软件</a>