title: 4 魔道UDP协议 人头狗
date: '2019-11-05 15:55:49'
updated: '2019-11-05 15:55:49'
tags: [网络协议]
permalink: /articles/2019/11/05/1572940548851.html
---
UDP 是User Datagram Protocol的简称， 中文名是用户数据报协议，是OSI（Open System Interconnection，开放式系统互联） 参考模型中一种无连接的传输层协议

### 前面一篇说了TCP那么怎么机器怎么区分你是UDP还是TCP呢？
补一个前面IP头的图：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191105152025912.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1hIdXJyaWNhbmU=,size_16,color_FFFFFF,t_70)
这里IP里面有个协议，指的就是IP数据里面是什么协议，ICMP协议号为1，TCP协议号为6，UDP的协议号为17。

### 看格式总结UDP的特点

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191105152732738.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1hIdXJyaWNhbmU=,size_16,color_FFFFFF,t_70)

 1. 端口号：用来把数据指定给监听该端口的应用程序。
 2. 长度+校验和：简单讲都是为了保证传输的内容正确性。
 3. 数据，里面装点文件之类的。

 
 可以发现和TCP相比，这个是极其简单的。它的特点可以和TCP对比，总的来说就是TCP有的特点它没有😂。

 - 没有连接。可以一对多。
 - 没有顺序。
- 不管丢包。
- 不控制流量。在拥堵的情况，有时候反而是优势。
- 简单，资源要求低。

### 应用场景

 - 直播
 - 广播
 - 视频
总的来说可以接受它上面的特点的应用都可以用它。
或者在自己的应用里面控制连接、顺序、丢包、流量这些，定制得比较深入，那么TCP就多余了，可以用UDP。

如果TCP是个游戏高手有自己的节奏的话，UDP就是个新手，别的不管只管冲，江湖人称送人头狗User head Dog Present。

 参考：
刘超 趣谈网络协议
搜狗百科

联系我：
JS、JAVA程序调试；
网站、小程序、APP项目；
qq：1582508336 魔道工程师
 
