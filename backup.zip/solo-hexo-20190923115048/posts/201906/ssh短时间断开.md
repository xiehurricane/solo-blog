title: ssh短时间断开
date: '2019-06-23 16:30:30'
updated: '2019-06-23 16:30:30'
tags: [Linux]
permalink: /articles/2019/06/23/1561278630204.html
---
* vi /etc/ssh/sshd_config

```
`ClientAliveInterval 10 　　＃server每隔10秒发送一次请求给client（连接保持的时间），然后client响应，从而保持连接`

`ClientAliveCountMax 30　　＃server发出请求后，客户端没有响应得次数达到30（30*10s=5分钟），就自动断开连接`
```

*  :wq
* service sshd reload 

centos 7.2
断开后再连才有效。